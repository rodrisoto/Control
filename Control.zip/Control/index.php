<?php
header("Location: stock.php");
?>